import ar from "./languages/ar";
const messages = {
  "pt-BR": ptBR,
  en,
  es,
  ar,
};
